<?php
return array(
	// Lif
	6001 => 'Lif',
	6009 => 'Lif',
	6005 => 'Lif',
	6013 => 'Lif',
	
	// Amistr
	6002 => 'Amistr',
	6010 => 'Amistr',
	6006 => 'Amistr',
	6014 => 'Amistr',
	
	// Filir
	6003 => 'Filir',
	6011 => 'Filir',
	6007 => 'Filir',
	6015 => 'Filir',
	
	// Vanilmirth
	6004 => 'Vanilmirth',
	6012 => 'Vanilmirth',
	6008 => 'Vanilmirth',
	6016 => 'Vanilmirth',
	
	// Homunculus S
	6048 => 'Eira',
	6049 => 'Bayeri',
	6050 => 'Sera',
	6051 => 'Dieter',
	6052 => 'Elanor'
);
?>
