<?php
// rA monster sizes.
return array(
	 0 => 'Small',
	 1 => 'Medium',
	 2 => 'Large'
)
?>
