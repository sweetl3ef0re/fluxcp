<?php
// rA attributes.
return array(
	1 => 'Ice',
	2 => 'Earth',
	3 => 'Fire',
	4 => 'Wind',
);
?>
