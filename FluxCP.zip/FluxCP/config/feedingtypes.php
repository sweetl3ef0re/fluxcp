<?php
return array(
    'P' => 'Pet',
    'H' => 'Homunculus',
    'O' => 'Other',
);
