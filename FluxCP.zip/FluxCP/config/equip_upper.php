<?php
return array(
	1 => 'Normal',
	2 => 'Upper',
	4 => 'Baby',
	8 => 'Third',
	16 => 'Third Upper',
	32 => 'Third Baby'
)
?>
