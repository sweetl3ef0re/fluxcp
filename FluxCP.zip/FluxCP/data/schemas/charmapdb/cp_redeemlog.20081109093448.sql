ALTER TABLE  `cp_redeemlog` ADD INDEX (  `nameid` ,  `account_id` ,  `char_id` ) ;
