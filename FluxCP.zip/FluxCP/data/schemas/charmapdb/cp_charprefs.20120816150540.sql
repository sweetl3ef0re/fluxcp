ALTER TABLE `cp_charprefs` ADD INDEX (`char_id`);
