ALTER TABLE `cp_txnlog` CHANGE `referrer_id` `referrer_id` VARCHAR(13) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;
